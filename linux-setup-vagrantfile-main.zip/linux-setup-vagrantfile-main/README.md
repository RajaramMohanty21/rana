# linux-setup-vagrantfile
this repo contain vagrantfile and steps for setup centos7 server
Step-1
install Vagrant on your Windows10 computer.
Download Link:
https://www.vagrantup.com/downloads
Step-2
Install VirtualBox on your Windows10 Computer
Download Link:
https://download.virtualbox.org/virtualbox/6.1.34/VirtualBox-6.1.34-150636-Win.exe

https://www.virtualbox.org/wiki/Downloads

Stape-3
Downlod the Vagrantfile and Create a Folder Paste That Vagrantfile .

Stape-4
Open Git Bash inside the folder .

Run The bellow Command 
1. for start: 
vagrant up
2. for shortdown: 
vagrant halt




Thanks
Devops 0dia
